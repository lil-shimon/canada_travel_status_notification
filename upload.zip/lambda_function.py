def lambda_handler():
  print("test handler")

if __name__ == '__main__':
  lambda_handler()